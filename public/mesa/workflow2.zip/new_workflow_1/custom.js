const Mesa = require('vendor/Mesa.js');

/**
 * A Mesa Script exports a class with a script() method.
 */
module.exports = new class {

  /**
   * Mesa Script
   *
   * @param {object} payload The payload data
   * @param {object} context Additional context about this task
   */
  script = (payload, context) => {
    const vars = context.steps;
    let orders = vars.shopify;

    let lastOrder = orders[0];
    Mesa.trigger.setTaskExternalData({
      "label": "Order " + lastOrder.name + " has tags: " + lastOrder.tags
    });

    let tags = lastOrder.tags.split(',');

    if (tags.includes('returned')) {
      throw Error("Order has already been returned: " + lastOrder.name);
    }

    Mesa.output.next({"lastOrder": lastOrder});
  }
}
